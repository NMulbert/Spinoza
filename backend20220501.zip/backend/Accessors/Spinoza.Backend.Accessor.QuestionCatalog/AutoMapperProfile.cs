﻿using AutoMapper;

internal class AutoMapperProfile : Profile
{
    public AutoMapperProfile()
    {
       
    }
}

